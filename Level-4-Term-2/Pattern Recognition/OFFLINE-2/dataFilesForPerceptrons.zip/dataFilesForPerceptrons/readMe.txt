1. trainLinearlySeparable.txt : Thefirst row contains three integers: the no. of features (d), the no. of classes (m) and the total number of samples (n).Tthe following n lines contain the features and classes of all n patterns.

2. trainLinearlyNonSeparable.txt: the file format is sample as trainLinearlySeparable.txt; however, the samples are not linearly separable. this file can be used to train the pocket algorithm.

3. testLinearlySeparable.txt : The file consists of multiple line of numbers. each line represents a sample consisting of d feature valuse and its true class.

4. testLinearlyNonSeparable.txt: The file has the same format as testLinearlySeparable.txt; however it should be used to verify the performance of pocket algorithm.